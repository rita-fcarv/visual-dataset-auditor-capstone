# GPU-Accelerated Visual Dataset Auditor

## Project overview

This project implements a GPU-accelerated image dataset auditing
application using CUDA, C++, and OpenCV.

The application processes image collections, extracts image quality
metrics, computes perceptual hashes, and identifies visually similar
image pairs. It produces CSV reports suitable for dataset inspection.

## Algorithms and CUDA techniques

The project uses custom CUDA kernels for grayscale conversion,
image intensity analysis, Laplacian-based sharpness estimation,
difference hashing, and pairwise Hamming distance computation.

GPU parallelism is used to distribute independent pixel operations
and image-pair comparisons across threads.

The similarity implementation was optimised to avoid transferring
an entire pairwise distance matrix to the CPU. Instead, it processes
unique pairs and collects matching results.

## Challenges

One challenge was ensuring that CPU and GPU image processing
implementations produced equivalent results. Minor grayscale
differences were observed because of floating-point rounding;
the maximum difference was one intensity level.

Another challenge was GPU overhead. For small images and small
datasets, allocation, launch, and transfer costs can exceed the
benefit of parallel execution.

The original GPU similarity implementation also transferred more
data than necessary. Reducing this overhead improved performance.

## Evaluation

The similarity detector was evaluated on 120 synthetic images,
representing 7,140 possible pairs and 200 expected matches.

At a Hamming distance threshold of 5, the detector achieved
precision, recall, and F1 score of 1.0000 on this dataset.

Performance benchmarks showed:

- Grayscale conversion: 2.36x GPU speedup at 1024x1024
- Image quality metrics: 2.79x GPU speedup at 1024x1024
- Similarity detection: 5.89x GPU speedup at 1,000 images

These results are specific to the test environment and workloads.

## Lessons learned

The project demonstrated that GPU acceleration depends on workload
size, memory movement, and algorithm design—not just parallel
execution.

It also highlighted the importance of correctness validation,
representative benchmarks, reproducible test datasets, and careful
interpretation of performance measurements.

## Future improvements

Potential improvements include GPU memory reuse, streaming image
batches, more robust perceptual hashing, scalable candidate
generation for very large datasets, and validation on real-world
image collections.
